Author: Yves Ledru



This example illustrates how one can define the rules 
for calculating who will qualify in the world 
championship in soccer given different initial groups. 
This model is made for the championship in 2000 but it 
could easily be updated to reflect the any championships. 
In the test class UseGP there are a few examples of 
using the traces primitives used for test automation.
 

Language Version: vdm10