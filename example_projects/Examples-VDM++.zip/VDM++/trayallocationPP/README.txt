Author: Kim Bjerge and José Antonio Esparza Jaesparza


This VDM++ model is made by two students of a sortation system
able to sort parcels into different trays for example for an
airport sorting suitcases for different flights. The model here
focus on the algorithm for prioritising between different feeders
to the conveyer belt


Language Version: vdm10
Entry point     : new World().Run()