Author: Nick Battle



This example is made by Nick Battle and it illustrates how one can 
perform the traditional factorial functionality using the concurrency
primitives in VDM++.


Language Version: classic
Entry point     : new Factorial().factorial(20)