Author: Johannes Ulfkjær Jensen, Jon Nielsen and Leni Lausdahl


This example is produced by a group of students as a part
of a VDM course given at the Engineering College of Aarhus. 
This model describes how to do code generation from a small 
applicative language called Simple to a subset of Java (called
Geraffe). This example also illustrates how one can make use
of Java jar files as a part of a VDM model supported by
Overture.  

Language Version: classic
Entry point     : new codegen_Util().Run()