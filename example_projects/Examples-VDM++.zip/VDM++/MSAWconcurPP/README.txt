Author: Augusto Ribeiro


This VDM++ model is made by August Ribeiro as input for the VDM
courses delivered at IHA in Denmark. It is a concurrent version 
of the Minimum Safety Altitude Warning System (MSAW) example.

This project is currently not running with the Overture interpreter.


Language Version: vdm10
Entry point     : new World().Run()