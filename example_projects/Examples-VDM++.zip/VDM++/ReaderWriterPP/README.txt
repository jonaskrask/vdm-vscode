Author: 




Language Version: vdm10
Entry point     : new TestClass().Run()