Author: Sten Agerholm, Peter Gorm Larsen and Kim Sunesen


This model is described in the sequential subset of VDM++. 
This enables abstraction from design considerations and ensures 
maximum focus on high-level, precise and systematic analysis. This
was developed by Sten Agerholm, Peter Gorm Larsen and Kim Sunesen 
in 1999 in connection with FM'99.


Language Version: vdm10
Entry point     : new SimpleTest().Run()